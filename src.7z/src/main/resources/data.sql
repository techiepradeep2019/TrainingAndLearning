INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(100, 'Pradeep', 1000.1001, 'Senior Consultant', 'Capgemini');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(101, 'Deepak', 1111.1001, 'Senior Software Engineer', 'Sap Labs');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(102, 'Leena', 2222.1001, 'Technical Architect', 'Morgan Stanley');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(103, 'Leena', 3333.1001, 'Technical Architect', 'Morgan Stanley');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(104, 'XXXX', 1000.1001, 'XXXX', 'XXXX');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(105, 'YYYY', 1111.1001, 'YYYY', 'YYYY');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(106, 'ZZZZ', 2222.2222, 'ZZZZ', 'ZZZZ');
INSERT INTO Employee(emp_id, emp_name, salary, designation, company_name) values(107, 'MMMM', 3333.1001, 'MMMM', 'MMMM');