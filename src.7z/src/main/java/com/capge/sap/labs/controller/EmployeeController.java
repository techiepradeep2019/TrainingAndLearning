package com.capge.sap.labs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capge.sap.labs.model.Employee;

@RestController
@RequestMapping("/employee")
@CrossOrigin("http://localhost:4200")
public class EmployeeController {

	@Autowired
	EmployeeRepository empRepo;

	@GetMapping("/{empId}")
	Employee getEmployee(@PathVariable final int empId) {
		Optional<Employee> optEmp = empRepo.findById(empId);
		if (optEmp.isPresent()) {
			return optEmp.get();
		}
		return null;
	}

	@GetMapping(produces = MediaType.APPLICATION_XML_VALUE)
	List<Employee> getAllEmployees() {
		return empRepo.findAll();
	}

}
