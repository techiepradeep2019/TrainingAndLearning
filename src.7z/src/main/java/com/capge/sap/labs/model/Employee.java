package com.capge.sap.labs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "Employee")
@XmlRootElement(name = "employee")
public class Employee {

	@Id
	@Column(name = "empId")
	@XmlAttribute(name = "empId")
	private int empId;

	@Column(name = "empName")
	@XmlAttribute(name = "empName")
	private String empName;

	@Column(name = "salary")
	@XmlAttribute(name = "salary")
	private double salary;

	@Column(name = "designation")
	@XmlAttribute(name = "designation")
	private String designation;

	@Column(name = "companyName")
	@XmlAttribute(name = "companyName")
	private String companyName;

	public Employee() {
	}

	public Employee(int empId, String empName, double salary, String designation, String companyName) {
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.designation = designation;
		this.companyName = companyName;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public double getSalary() {
		return salary;
	}

	public String getDesignation() {
		return designation;
	}

	public String getCompanyName() {
		return companyName;
	}

}
