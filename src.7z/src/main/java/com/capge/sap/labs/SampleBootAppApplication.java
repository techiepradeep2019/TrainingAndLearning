package com.capge.sap.labs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleBootAppApplication.class, args);
	}

//	@Bean("employeeMap")
//	Map<Integer, Employee> employeeMap() {
//		return Map.of(100, new Employee(100, "Pradeep", 1000.1001, "Senior Consultant", "Capgemini"), 101,
//				new Employee(101, "Deepak", 1111.1001, "Senior Software Engineer", "Sap Labs"), 102,
//				new Employee(102, "Leena", 2222.1001, "Technical Architect", "Morgan Stanley"), 103,
//				new Employee(103, "Leena", 3333.1001, "Technical Architect", "Morgan Stanley"));
//
//	}

//	@Bean("employeesMap")
//	Map<Integer, Employee> employeesMap() {
//		Map<Integer, Employee> map = new HashMap<>();
//		empRepo.findAll().forEach(emp -> map.put(emp.getEmpId(), emp));
//		return map;
//	}

}
