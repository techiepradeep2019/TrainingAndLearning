import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class TestSorting {
	public static void main(String[] args) {
		List<EMP> empList = Arrays.asList(new EMP(3, "pradeep", 11.00, "LBS"), new EMP(1, "Ashok", 14.00, "LBS"),
				new EMP(2, "Deepak", 16.00, "FS"), new EMP(4, "Leena", 13.00, "FS"));
		System.out.println(empList);

		empList.sort(Comparator.comparingInt(EMP::getEmpID));
//		empList.sort(EMPComparator::compare);
		System.out.println(empList);
	}
}
