package com.dell.emc.interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class TestList {
	public static void main(String[] args) {

		List<Integer> listOne = new ArrayList(Arrays.asList(1, 2, 3, 4, 5, 6, 7));
		List<Integer> listTwo = new ArrayList(Arrays.asList(1, 2, 3, 10, 9, 4, 11));
		System.out.println("LIST-1:\t" + listOne);
		System.out.println("LIST-2:\t" + listTwo);

		listTwo.sort((n1, n2) -> {
			return (n1 - n2);
		});

		System.out.println("After Sort - LIST-2:\t" + listTwo);

		System.out.println("---------------InterSection1-------------------------------------");
		long startTime = System.currentTimeMillis();
		System.out.println("Start Time : " + startTime);
		InterSection1(listOne, listTwo);
		System.out.println("End Time : " + System.currentTimeMillis());

		System.out.println("LIST-1:\t" + listOne);
		System.out.println("LIST-2:\t" + listTwo);
		System.out.println("---------------InterSection1-------------------------------------");

	}

	private static void InterSection1(List<Integer> listOne, List<Integer> listTwo) {
		Iterator<Integer> itrListTwo = listTwo.iterator();

		while (itrListTwo.hasNext()) {
			int num = itrListTwo.next();
			if (Boolean.FALSE == listOne.contains(num)) {
				itrListTwo.remove();
			}
		}
	}
}
