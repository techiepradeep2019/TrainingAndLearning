package com.dell.emc.interview;

class MyOwnLinkedList {

	class Node {
		Object item;
		Node next;

		Node(Object item, Node next) {
			this.item = item;
			this.next = next;
		}

		@Override
		public String toString() {
//			return "Node[item=" + item + ", next=" + next + "]";
			return "Node[" + item + ", " + next + "]";
		}

	}

	private Node firstNode;
	private Node currentNode;

	Node removeItem(Object item) {
		if (firstNode == null) {
			System.out.println("List is Empty");
			return null;
		}
		if (firstNode.item == item) {
			firstNode = firstNode.next;
			return firstNode;
		}
		for (Node tempNode = firstNode, previousNode = firstNode; tempNode != null; previousNode = tempNode, tempNode = tempNode.next) {

			if (tempNode.item == item) {

				previousNode.next = tempNode.next;
				return tempNode;

			}

		}
		return null;
	}

	void addItem(Object item) {
		if (firstNode == null) {
			firstNode = new Node(item, null);
			currentNode = firstNode;
		} else {

			Node nextNode = new Node(item, null);
			currentNode.next = nextNode;
			currentNode = nextNode;

		}
	}

	void disp() {
		System.out.println(firstNode);
	}

}

public class TestLinkedList {

	public static void main(String[] args) {
		testLinkedList2();
	}

	private static void testLinkedList2() {
		MyOwnLinkedList myLinkedList = new MyOwnLinkedList();
		myLinkedList.addItem("Ten");
		myLinkedList.addItem("Fourty");
		myLinkedList.addItem("Thirty");

		myLinkedList.addItem("Seventy");
		myLinkedList.addItem("Ninety");
		myLinkedList.addItem("Eighty");

		myLinkedList.addItem("Twenty");
		myLinkedList.addItem("Sixty");
		myLinkedList.addItem("Fifty");

		myLinkedList.disp();

		MyOwnLinkedList.Node node = myLinkedList.removeItem("Ten");
		if (node == null) {
			System.out.println("Either the list is Empty or Specified Node does not exsists");
		} else {
			System.out.println("REMOVED:\n NODE[" + node.item + ",node] from the list \n");
		}

		myLinkedList.disp();
	}

	private static void testLinkedList1() {
		MyOwnLinkedList myLinkedList = new MyOwnLinkedList();
		myLinkedList.addItem(10);
		myLinkedList.addItem(40);
		myLinkedList.addItem(30);

		myLinkedList.addItem(70);
		myLinkedList.addItem(90);
		myLinkedList.addItem(80);

		myLinkedList.addItem(20);
		myLinkedList.addItem(60);
		myLinkedList.addItem(50);

		myLinkedList.disp();

		myLinkedList.removeItem(60);

		myLinkedList.disp();
	}
}