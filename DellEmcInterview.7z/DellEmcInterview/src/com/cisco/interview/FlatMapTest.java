package com.cisco.interview;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class FlatMapTest {
	static void testFlatMap() {
		List<EMP> empList = Arrays.asList(new EMP("Pradeep", "Ramaiah"), new EMP("Deepak", "Singh"),
				new EMP("Raj", "Kumar"), new EMP("Ashok", "Singhal"), new EMP("Kiran", "Reddy"));

		System.out.println(empList);

		List<String> listFNames = empList.stream().flatMap(emp -> Stream.of(emp.getFirstName()))
				.collect(Collectors.toList());

		List<String> listOfFNames = empList.stream().map(emp -> emp.getFirstName()).collect(Collectors.toList());

		System.out.println("After Mapping : ");
		System.out.println(listFNames);

		System.out.println(listOfFNames);

	}

	static void testListOfList() {
		List<List<String>> listOfNameList = Arrays.asList(Arrays.asList("Pradeep", "Ramaiah", "Deepak", "Singh"),
				Arrays.asList("Raj", "Kumar", "Ashok", "Singhal"), Arrays.asList("Kiran", "Reddy"));
		System.out.println(listOfNameList);
		List<String> listOfNames = listOfNameList.stream().flatMap(nameList -> nameList.stream())
				.collect(Collectors.toList());
		System.out.println("After merging all lists : " + listOfNames);
	}
}
