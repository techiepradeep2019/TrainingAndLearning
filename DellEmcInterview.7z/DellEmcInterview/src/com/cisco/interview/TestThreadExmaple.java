package com.cisco.interview;

public class TestThreadExmaple {
	boolean flag = false;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

		TestThreadExmaple obj = new TestThreadExmaple();
		Thread oddThread = new Thread(() -> {
			for (int i = 0; i < arr.length; i += 2) {
				synchronized (arr) {
					if (Boolean.TRUE == obj.isFlag()) {
						try {
							arr.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + arr[i] + "\t");
					obj.setFlag(true);
					arr.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}, "OddThread");

		Thread evenThread = new Thread(() -> {
			for (int i = 1; i < arr.length; i += 2) {
				synchronized (arr) {
					if (Boolean.FALSE == obj.isFlag()) {
						try {
							arr.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + arr[i] + "\t");
					obj.setFlag(false);
					arr.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}, "EvenThread");

		evenThread.start();
		oddThread.start();

		try {
			evenThread.join();
			oddThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("\nMain Thread completed its execution");
	}

}
