package com.cisco.interview;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Test1 implements Runnable {

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " : TEST-1");
	}
}

class Test2 implements Runnable {

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " : TEST-2");

	}
}

public class TestExecutor {

	public static void main(String[] args) {

		ExecutorService executor = Executors.newFixedThreadPool(2);
		if (Boolean.FALSE == executor.isTerminated()) {
			executor.execute(new Test1());
			executor.execute(new Test2());

		}
		executor.shutdown();
	}

}
