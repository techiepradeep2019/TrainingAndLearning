package com.cisco.interview;

public class TestSorting {

	public static void main(String[] args) {
//		int a[] = { 10, 9, 7, 101, 23, 44, 12, 78, 34, 23 };

		int a[] = { 8, 10, 9, 1, 7, 101, 6, 23, 5, 44, 2, 12, 78, 4, 34, 23 };

		System.out.println("Before Sort : ");

		dispArr(a);
//		bubbleSort(a);
//		insertionSort(a);
//		myBubbleSort(a);
		myOwnBubbleSort(a);
		System.out.println("\nAfter Sort : ");
		dispArr(a);
	}

	private static void dispArr(int[] a) {
		for (int num : a) {
			System.out.print(num + " , ");
		}
	}

	public static void insertionSort(int array[]) {
		int n = array.length;
		for (int j = 1; j < n; j++) {
			int key = array[j];
			int i = j - 1;
			while ((i > -1) && (array[i] > key)) {
				array[i + 1] = array[i];
				i--;
			}
			array[i + 1] = key;
		}
	}

	private static void myOwnBubbleSort(int arr[]) {

		for (int i = 0; i <= (arr.length / 2); i++) {

			int small = arr[i], big = arr[i], smallIndex = -1, bigIndex = -1;

			for (int j = i + 1; j < (arr.length - i) - 1; j++) {
				if (small > arr[j]) {
					small = arr[j];
					smallIndex = j;
				}
				if (big < arr[j]) {
					big = arr[j];
					bigIndex = j;
				}
			}
			if (smallIndex != -1) {
				int temp = arr[smallIndex];
				int temp1 = arr[i + 1];
				arr[i + 1] = arr[i];
				arr[i] = temp;
				arr[smallIndex] = temp1;

			}
			if (bigIndex != -1) {
				int temp = arr[bigIndex];
				int temp1 = arr[(arr.length - i) - 2];
				arr[(arr.length - i) - 2] = arr[(arr.length - i) - 1];
				arr[(arr.length - i) - 1] = temp;
				arr[bigIndex] = temp1;
			}

		}

	}

	private static void myBubbleSort(int arr[]) {
		for (int i = 0; i != (arr.length - i)/* i < (arr.length / 2) */; i++) {
			int small = arr[i], big = arr[i], smallIndex = -1, bigIndex = -1;
			for (int j = i + 1; j < (arr.length - i); j++) {
				if (small > arr[j]) {
					small = arr[j];
					smallIndex = j;
				}
				if (big < arr[j]) {
					big = arr[j];
					bigIndex = j;
				}

			}
			if (smallIndex != -1) {
				int temp = arr[i];
				arr[i] = small;
				arr[smallIndex] = temp;
			}
			if (bigIndex != -1) {
				int temp = arr[arr.length - i - 1];
				arr[arr.length - i - 1] = big;
				arr[bigIndex] = temp;
			}
		}
	}

	private static void bubbleSort(int arr[]) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < (arr.length - i - 1); j++) {
				if (arr[j] > arr[j + 1])
					swap(arr, j, j + 1);
			}
		}
	}

	private static void swap(int[] arr, int i, int j) {
		int temp = arr[j];
		arr[j] = arr[i];
		arr[i] = temp;
	}

}
