package com.cisco.interview;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

class PrimeCheck {
	static void testPrime() {
		List<Integer> intList = Arrays.asList(4, 10, 3, 6, 8, 9, 34, 33, 27, 22, 11);
		System.out.println("Int List : " + intList);

		System.out.println("Prime List : ");
		Predicate<Integer> predPrime = n -> ((n % 2) != 0);
//		predPrime = predPrime.or(n -> ((n % 3) != 0));

		List<Integer> primeList = intList.stream().filter(predPrime).collect(Collectors.toList());

		Map<Integer, List<Integer>> mapPrimeList = intList.stream().filter(n -> ((n % 2) != 0))
				.collect(Collectors.groupingBy(n -> n));

		List<Integer> primeListNew = intList.stream().filter(num -> isPrime(num)).collect(Collectors.toList());
		System.out.println("MAP Prime List : " + mapPrimeList);
		System.out.println("Prime List : " + primeList);
		System.out.println("Prime List New: " + primeListNew);
	}

	private static boolean isPrime(int num) {
		boolean flag = true;
		for (int i = 2; i <= num / 2; i++) {
			if ((num % i) == 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}
}