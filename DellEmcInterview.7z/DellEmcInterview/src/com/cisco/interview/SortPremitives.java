package com.cisco.interview;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class SortPremitives {

	static void sortInteger() {
		List<Integer> intList = Arrays.asList(10, 4, 5, 3, 8, 2, 1, 9, 6, 7);
		System.out.println("Before Sort : \n" + intList);

		intList.sort(Comparator.comparingInt(Integer::intValue));
		System.out.println("After Sort : \n" + intList);
	}

	static void sortString() {
		List<String> nameList = Arrays.asList("Raj", "Kumar", "Ashok", "Singhal");

		System.out.println("Before Sort : \n" + nameList);
		List<String> sortedNameList = nameList.stream().sorted().collect(Collectors.toList());

		System.out.println("After Sort : \n" + sortedNameList);

		nameList.sort(Comparator.comparing(String::valueOf));
		System.out.println("After Sort : \n" + nameList);
	}
}