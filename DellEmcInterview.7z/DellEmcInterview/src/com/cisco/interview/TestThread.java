package com.cisco.interview;

class MyNumbers {
	private int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

	public int[] getArr() {
		return arr;
	}

	private boolean flag = false;

	void print(int index) {
		System.out.print(Thread.currentThread().getName() + " is printing\t" + this.arr[index] + "\t");
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}

public class TestThread {

	public static void main(String[] args) {
		MyNumbers obj = new MyNumbers();

		Thread oddThread = new Thread(() -> {
			for (int i = 0; i < obj.getArr().length; i += 2) {
				synchronized (obj) {
					if (Boolean.TRUE == obj.isFlag()) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					obj.print(i);
					obj.setFlag(true);
					obj.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}, "OddThread");

		Thread evenThread = new Thread(() -> {
			for (int i = 1; i < obj.getArr().length; i += 2) {
				synchronized (obj) {
					if (Boolean.FALSE == obj.isFlag()) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					obj.print(i);
					obj.setFlag(false);
					obj.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}, "EvenThread");

		evenThread.start();
		oddThread.start();

		try {
			evenThread.join();
			oddThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("\nMain Thread completed its execution");
	}

}
