package com.cisco.interview;

public class TestJava {
	public static void main(String[] args) {

//		PrimeCheck.testPrime();
//
//		ListComparator.testList();
//		ListComparator.testSorting();
//
//		AnagramTest.testAnagram();
		AnagramTest.testAnagramJava8Way();

//		FlatMapTest.testFlatMap();
//		FlatMapTest.testListOfList();
//
//		SortPremitives.sortString();
//		SortPremitives.sortInteger();

	}
}
