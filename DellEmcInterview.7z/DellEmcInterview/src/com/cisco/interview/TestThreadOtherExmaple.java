package com.cisco.interview;

public class TestThreadOtherExmaple {
	boolean flag = false;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public static void main(String[] args) {
		int firstArr[] = { 1, 3, 5, 7, 9 };

		int secondArr[] = { 2, 4, 6, 8, };

		TestThreadOtherExmaple obj = new TestThreadOtherExmaple();
		Thread oddThread = new Thread(() -> {
			for (int i = 0; i < firstArr.length; i++) {
				synchronized (obj) {
					if (Boolean.TRUE == obj.isFlag()) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + firstArr[i] + "\t");
					obj.setFlag(true);
					obj.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}, "OddThread");

		Thread evenThread = new Thread(() -> {
			for (int i = 0; i < secondArr.length; i++) {
				synchronized (obj) {
					if (Boolean.FALSE == obj.isFlag()) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + secondArr[i] + "\t");
					obj.setFlag(false);
					obj.notify();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}, "EvenThread");

		evenThread.start();
		oddThread.start();

		try {
			evenThread.join();
			oddThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("\nMain Thread completed its execution");
	}

}
