package com.cisco.interview;

enum ThreadEnum {
	OddThread("OddThread"), EvenThread("EvenThread"), SpecialThread("SpecialThread");
	private String threadName;

	ThreadEnum(String threadName) {
		this.threadName = threadName;
	}

	String getName() {
		return threadName;
	}
}

public class TestMultipleThreadExmaple {

	public String getThreadName() {
		return threadName;
	}

	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	String threadName = "OddThread";

	public static void main(String[] args) {
		int firstArr[] = { 1, 3, 5, 7, 9 };

		int secondArr[] = { 2, 4, 6, 8, };

		int thirdArr[] = { 10, 20, 30, 40, 50 };

		TestMultipleThreadExmaple obj = new TestMultipleThreadExmaple();
		Thread oddThread = new Thread(() -> {
			for (int i = 0; i < firstArr.length; i++) {
				synchronized (obj) {
					if (Boolean.FALSE == obj.getThreadName().equalsIgnoreCase(ThreadEnum.OddThread.getName())) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + firstArr[i] + "\t");
					obj.setThreadName(ThreadEnum.EvenThread.getName());
					obj.notify();
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
				}

			}
			obj.setThreadName(ThreadEnum.EvenThread.getName());
		}, "OddThread");

		Thread evenThread = new Thread(() -> {
			for (int i = 0; i < secondArr.length; i++) {
				synchronized (obj) {
					if (Boolean.FALSE == obj.getThreadName().equalsIgnoreCase(ThreadEnum.EvenThread.getName())) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + secondArr[i] + "\t");
					obj.setThreadName(ThreadEnum.SpecialThread.getName());
					obj.notify();
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
				}

			}
			obj.setThreadName(ThreadEnum.SpecialThread.getName());
		}, "EvenThread");

		Thread specialThread = new Thread(() -> {
			for (int i = 0; i < thirdArr.length; i++) {
				synchronized (obj) {
					if (Boolean.FALSE == obj.getThreadName().equalsIgnoreCase(ThreadEnum.SpecialThread.getName())) {
						try {
							obj.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.print(Thread.currentThread().getName() + " is printing\t" + thirdArr[i] + "\t\n");
					obj.setThreadName(ThreadEnum.OddThread.getName());
					obj.notify();
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
				}

			}
			obj.setThreadName(ThreadEnum.OddThread.getName());
		}, "SpecialThread");

		evenThread.start();
		oddThread.start();
		specialThread.start();

		try {
			evenThread.join();
			oddThread.join();
			specialThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("\nMain Thread completed its execution");
	}

}
