package com.cisco.interview;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

class ListComparator {
	// Sorting In Descending order of Length of FirstName else length of LastName
	private static Comparator<EMP> empComparator = (e1, e2) -> {
		int result = (e2.getFirstName().length() - e1.getFirstName().length());
		if (result != 0)
			return result;
		else
			return (e2.getLastName().length() - e1.getLastName().length());
	};

	static void testList() {
		List<EMP> empList = Arrays.asList(new EMP("Pradeep", "Ramaiah"), new EMP("Deepak", "Singh"),
				new EMP("Raj", "Kumar"), new EMP("Ashok", "Singhal"), new EMP("Kiran", "Reddy"));

		System.out.println(empList);

		// Sorting In Descending order of Length of FirstName else length of LastName
		empList.sort(empComparator);

		System.out.println("After Sort : ");
		System.out.println(empList);
	}

	static void testSorting() {
		List<EMP> listOfEmp = Arrays.asList(new EMP("Pradeep", "Ramaiah"), new EMP("Deepak", "Singh"),
				new EMP("Deepak", "Timmaiah"), new EMP("Aruna", "Gowda"), new EMP("Arjun", "kumar"));
		System.out.println("Before Sort : " + listOfEmp);
		listOfEmp.sort(Comparator.comparing(EMP::getFirstName).thenComparing(EMP::getLastName));
		System.out.println("After Sort : " + listOfEmp);
	}
}
