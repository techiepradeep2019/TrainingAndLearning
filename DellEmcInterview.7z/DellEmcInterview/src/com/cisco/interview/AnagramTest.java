package com.cisco.interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AnagramTest {

	static void testAnagram() {
		String sentence = "cat tac atc dog car rat rac god fog owl tar";
		System.out.println(sentence);

		List<String> listWords = Arrays.asList(sentence.split(" "));
		System.out.println(listWords);

		Map<String, List<String>> mapAnagrams = new HashMap<>();

		listWords.forEach(word -> {
			String key = sortChars(word);
			if (mapAnagrams.containsKey(key)) {
				mapAnagrams.get(key).add(word);
			} else {
				mapAnagrams.put(key, new ArrayList<String>());
			}
		});
		System.out.println(mapAnagrams);
	}

	static void testAnagramJava8Way() {
		String sentence = "cat tac atc dog car rat rac god fog owl tar";

		System.out.println(sentence);

		Stream<String> stream = Arrays.stream(sentence.split(" "));

		Map<String, List<String>> anagramsTemp = stream.collect(Collectors.groupingBy(w -> sortChars(w)));

//		Map<String, List<String>> anagrams = stream.collect(Collectors
//				.groupingBy(w -> Stream.of(w.split("")).sorted().collect(Collectors.joining()), Collectors.toList()));
//
//		System.out.println("anagrams:\t" + anagrams);
		System.out.println("anagramsTemp:\t" + anagramsTemp);
	}

	private static String sortChars(String word) {
		char[] ch = word.toCharArray();
		Arrays.sort(ch);
		return String.valueOf(ch);
	}

}
