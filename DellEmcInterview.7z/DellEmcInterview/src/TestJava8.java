import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TestJava8 {

	public static void main(String[] args) {
//		testFlatMap();

//		testDBOpr();

//		testGroupBy();

//		findRepeativeCharactersWithIndex();
		findNumber();
	}

	private static void findNumber() {
		List<Integer> intList = Arrays.asList(11,-3, 10, 2, 6, 1, 8, 9, -10, 7, 10, 4, 5);
		System.out.println("intList : " + intList);
		int high = intList.get(0), secHigh = intList.get(0);
		for (int num : intList) {
			if (num > high) {
				secHigh = high;
				high = num;
			} else if (num > secHigh && num != high) {
				secHigh = num;
			}
		}
		System.out.println("Largest Number : " + high);
		System.out.println("Second Largest Number : " + secHigh);
	}

	private static void findNumberOtherWay() {
//		List<Integer> intList = Arrays.asList(11,-3, 10,2, 6, 1, 8, 9,-10, 7, 4, 5);
		List<Integer> intList = Arrays.asList(-3, 10, 2, 6, 1, 8, 9, -10, 7, 10, 4, 5);
//		intList.sort(Integer::compare);
		System.out.println("intList : " + intList);
		int secondHigh = intList.stream().filter(num -> num != intList.stream().max(Integer::compare).get())
				.max(Integer::compare).get();
		System.out.println("Maximum number is : " + intList.stream().max(Integer::compare).get());
		System.out.println("Second Maximum number is : " + secondHigh);
	}

	private static void findRepeativeCharactersWithIndex() {
		String name = "abcdeffhgijaklchabxyz".toLowerCase();
		System.out.println("Input value : " + name + "\n");
//		Map<Character, List<Integer>> mapCharacterIndexes = new HashMap<>();
//		for (int i = 0; i < name.length(); i++) {
//			if (mapCharacterIndexes.containsKey(name.charAt(i))) {
//				mapCharacterIndexes.get(name.charAt(i)).add(i);
//			} else {
//				mapCharacterIndexes.put(name.charAt(i), new ArrayList<Integer>());
//			}
//		}

		Map<Character, List<Integer>> mapCharacterRepeated = IntStream.range(0, name.length()).boxed()
				.collect(Collectors.groupingBy(name::charAt, HashMap::new, Collectors.toList()));

		System.out.println("Character found with these indexes :\n" + mapCharacterRepeated);

	}

	private static void testGroupBy() {
		List<CUST> custList = Arrays.asList(new CUST(100, "pradeep", 1000.12, 1, "Capgemini"),
				new CUST(120, "Deepak", 123.12, 2, "CTS"), new CUST(99, "Leena", 999.12, 1, "Capgemini"),
				new CUST(10, "Ashoka", 23000.12, 3, "HCL"), new CUST(67, "karthik", 60456.12, 1, "Capgemini"),
				new CUST(77, "harisha", 66645.12, 2, "CTS"), new CUST(20, "Kiran", 15000.12, 2, "CTS"),
				new CUST(63, "dimple", 44405.12, 3, "HCL"));

		custList.sort(Comparator.comparingInt(CUST::getGroupID));
		custList.forEach(System.out::println);

		Map<Integer, List<CUST>> mapCustGroup = custList.stream().collect(Collectors.groupingBy(CUST::getGroupID));
		System.out.println("\n map customer by group id : \n" + mapCustGroup);

//		Map<Integer, CUST> mapMaxSalryCUST = custList.stream()
//				.collect(Collectors.groupingBy(cust -> cust.getGroupID(), Collectors.collectingAndThen(
//						Collectors.maxBy(Comparator.comparingDouble(CUST::getSalary)), Optional::get)));
//		System.out.println("\nEmployees get max salary in their group :\n"+mapMaxSalryCUST);

	}

	private static void testDBOpr() {
		List<CUST> custList = Arrays.asList(new CUST(100, "pradeep", 1000.12), new CUST(120, "Deepak", 123.12),
				new CUST(99, "Leena", 999.12), new CUST(10, "Ashoka", 23000.12), new CUST(20, "Kiran", 15000.12));

		System.out.println(custList);

		Optional<CUST> optCUST = custList.stream().collect(Collectors.maxBy(Comparator.comparing(CUST::getSalary)));
		System.out.println(optCUST.isPresent() ? optCUST.get() : "Not Found");
	}

	private static void testFlatMap() {
		String[][] dataArray = new String[][] { { "a", "b" }, { "c", "d" }, { "e", "f" }, { "g", "h" } };

		System.out.println("dataArray : " + dataArray);

		Predicate<String> pred = str -> ("a".equalsIgnoreCase(str) || "h".equalsIgnoreCase(str));
//		pred = pred.or((str -> "h".equalsIgnoreCase(str)));

		List<String> listOfAllChars = Arrays.stream(dataArray).flatMap(x -> Arrays.stream(x)).filter(pred)
				.collect(Collectors.toList());

		System.out.printf("%s%s", "listOfAllChars :  ", listOfAllChars);
	}

}
