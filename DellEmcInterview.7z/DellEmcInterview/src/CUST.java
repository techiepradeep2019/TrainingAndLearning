
class CUST {
	private int custId;
	private String custName;
	private double salary;

	private int groupID;
	private String groupName;

	public CUST(int custId, String custName, double salary) {
		this.custId = custId;
		this.custName = custName;
		this.salary = salary;
	}

	public CUST(int custId, String custName, double salary, int groupID, String groupName) {
		this.custId = custId;
		this.custName = custName;
		this.salary = salary;
		this.groupID = groupID;
		this.groupName = groupName;
	}

	public int getCustId() {
		return custId;
	}

	public String getCustName() {
		return custName;
	}

	public double getSalary() {
		return salary;
	}

	public String getGroupName() {
		return groupName;
	}

	public int getGroupID() {
		return groupID;
	}

	@Override
	public String toString() {
		return "{" + custId + ", " + custName + ", " + salary + ", " + groupID + ", " + groupName + "}";
	}

}
