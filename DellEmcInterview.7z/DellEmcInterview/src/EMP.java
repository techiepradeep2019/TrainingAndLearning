
class EMP {
	private Integer empID;
	private String empName;
	private Double salary;
	private String deptName;

	public EMP() {

	}

	public EMP(Integer empID, String empName, Double salary, String deptName) {
		this.empID = empID;
		this.empName = empName;
		this.salary = salary;
		this.deptName = deptName;
	}

	public Integer getEmpID() {
		return empID;
	}

	public String getEmpName() {
		return empName;
	}

	public double getSalary() {
		return salary;
	}

	public String getDeptName() {
		return deptName;
	}

	@Override
	public String toString() {
		return "[" + empID + ", " + empName + ", " + salary + ", " + deptName + "]";
	}

}
