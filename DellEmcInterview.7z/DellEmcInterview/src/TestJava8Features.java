import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TestJava8Features {

	public static void main(String[] args) {
//		testList();
//		 testAssert();

//		testThread();

//		testprime();

		findSecondLargest();
	}

	private static void findSecondLargest() {
		List<Integer> intList = Arrays.asList(7, 3, 2, 4, 5, 8, 9, 10, 11, 13, 27, 34, 14);
		System.out.println("Intial List : " + intList);
		int smallElement = intList.stream().min(Integer::compare).get();
		int larElement = intList.stream().max(Integer::compare).get();
		int secondLarElement = intList.stream().filter(num -> num != larElement).max(Integer::compare).get();
		System.out.println("Small element :" + smallElement);
		System.out.println("Largest element : " + larElement);
		System.out.println("Second Largest Element : " + secondLarElement);
		intList.sort(Integer::compare);
		System.out.println("Sorted List : " + intList);
	}

	private static void testprime() {
		List<Integer> intList = Arrays.asList(7, 3, 2, 4, 5, 8, 9, 10, 11, 13, 27, 34, 14);
//		intList.sort(Integer::compare);
//		List<Integer> primeList = intList.stream()
//				.filter(num -> IntStream.rangeClosed(2, num / 2).noneMatch(val -> (num % val == 0)))
//				.collect(Collectors.toList());

		Predicate<Integer> pred = num -> IntStream.rangeClosed(2, num / 2).filter(i -> (num % i) == 0).findAny().isEmpty();
		List<Integer> primeList = intList.stream()
				.filter(pred)
				.collect(Collectors.toList());

		System.out.println("intList : \t" + intList);
		System.out.println("primeList :\t" + primeList);
	}

	static void disp(int startValue) {
		for (int i = startValue; i <= 10; i += 2)
			System.out.print(i + "\t");
	}

	private static void testThread() {
		Thread t1 = new Thread(() -> disp(1));
		Thread t2 = new Thread(() -> disp(2));
		t1.start();

		try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("\n");
		t2.start();

	}

	private static void testAssert() {
		int min1 = Arrays.stream(new int[] { 1, 2, 3, 4, 5 }).min().orElse(0);

		assert (1 == min1) : "Found the minimun value";

		System.out.println(min1 + "\t");
	}

	private static void testList() {
		Consumer<Integer> listConsumer = new Consumer<Integer>() {

			@Override
			public void accept(Integer t) {
				System.out.println(t);

			}
		};

		List<Integer> intList = Arrays.asList(1, 2, 3, 5, 4);
		intList.forEach(listConsumer);
		intList.forEach(System.out::println);
	}

}
