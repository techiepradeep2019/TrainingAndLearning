import java.util.Comparator;

public class EMPComparator implements Comparator<EMP> {

	@Override
	public int compare(EMP emp1, EMP emp2) {
		return emp1.getEmpID().compareTo(emp2.getEmpID());
	}

}
