import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileTest {

	public static void main(String[] args) {
		String fileName = "C:\\Users\\pr37\\Downloads\\passport folder.pdf";

		
		try (Stream<String> inputStream = Files.lines(Paths.get(fileName), StandardCharsets.ISO_8859_1)) {
            inputStream.forEach(System.out::println);
        } catch (IOException e) {
			e.printStackTrace();
		}
		
		
//		try (Scanner in = new Scanner(new FileInputStream(new File(filePath)), "UTF-8")) {
//			try (Scanner in = new Scanner(new FileReader(filePath))) {
//			while (in.hasNextLine()) {
//				System.out.println(in.nextLine());
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}

	}

}
