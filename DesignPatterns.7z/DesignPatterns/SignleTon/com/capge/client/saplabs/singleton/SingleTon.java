package com.capge.client.saplabs.singleton;

import java.io.Serializable;

public class SingleTon implements Serializable {

	private static final long serialVersionUID = -4222495992911062142L;
	private static volatile SingleTon INSTANCE;
	private static int count;

	private String singleTonName = "SingleTon";

	private SingleTon() {
		System.out.println(Thread.currentThread().getName() + " invoking Object Construction");
		count++;
	}

	public static SingleTon getInstance() {
		if (INSTANCE == null) {
			synchronized (SingleTon.class) {
				if (INSTANCE == null) {
					INSTANCE = new SingleTon();
				}
			}
		}
		return INSTANCE;
	}

	public static int getInstanceCount() {
		return count;
	}

	public String getSingleTonName() {
		return singleTonName;
	}

	public void setSingleTonName(String singleTonName) {
		this.singleTonName = singleTonName;
	}

	public Object readResolve() {
		System.out.println("....Invoking readResolve...");
		return INSTANCE;
	}

}
