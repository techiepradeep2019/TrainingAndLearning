package com.capge.client.saplabs.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;

import com.capge.client.saplabs.singleton.SingleTon;

public class TestSingleTon {
	private File file;

	File getFile() {
		if (this.file == null) {
			return new File("singleton.txt");
		}
		return file;

	}

	void deleteFile() {
		if (this.file != null) {
			System.out.println((Boolean.TRUE == file.delete()) ? " ! Deleted Successfully  !" : " ! Not deleted !");
		}
	}

	public static void main(String[] args) {
		final Random random = new Random();
		Thread[] threads = new Thread[10];

		for (int i = 0; i < 10; i++) {
			threads[i] = new Thread(() -> SingleTon.getInstance(), "Thread-" + random.nextInt(10));
			threads[i].start();
		}
		for (Thread thread : threads) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		SingleTon singleObject = SingleTon.getInstance();
		System.out.println("Number of objects created : " + SingleTon.getInstanceCount() + " \t And My name is : "
				+ singleObject.getSingleTonName());

		TestSingleTon testSingleTon = new TestSingleTon();
		testSingleTon.serialize(singleObject, testSingleTon.getFile());
		SingleTon otherObject = testSingleTon.deSerialize(testSingleTon.getFile());
		testSingleTon.deleteFile();

		System.out.println("Number of objects created After Serialization Process: " + SingleTon.getInstanceCount()
				+ " \t And My name is : " + otherObject.getSingleTonName());
		System.out.println(" \t But My name with original instance is : " + singleObject.getSingleTonName());
	}

	private SingleTon deSerialize(File file) {
		SingleTon singleObject = null;
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
			singleObject = (SingleTon) ois.readObject();
			singleObject.setSingleTonName("SingleTon-Deserialized");
			System.out.println("....Successfully De-Serialized....");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return singleObject;
	}

	private void serialize(SingleTon singleObject, File file) {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
			oos.writeObject(singleObject);
			System.out.println("....Successfully serialized....");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
