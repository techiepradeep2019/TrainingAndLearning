package com.capge.client.saplabs.decorator;

import com.capge.client.saplabs.bean.Vehicle;

public class WheelDecorator extends VehicleDecorator {

	private Vehicle v;
	private int wheels;
	private final StringBuilder builder = new StringBuilder();

	public WheelDecorator(Vehicle v, int wheels) {
		super(v);
		this.v = v;
		this.wheels = wheels;
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}

	@Override
	public String setUpVehicleType() {
		String vehicleType = v.setUpVehicleType();
		builder.append(vehicleType);
		return vehicleType;

	}

	@Override
	public String setUpWheel() {
		builder.append(" with ").append(wheels).append("-Wheeler");
		return " with " + wheels + "-Wheeler";

	}

	@Override
	public String setUpShape() {
		String shape = v.setUpShape();
		builder.append(shape);
		return " and " + shape + " in Shape" + " is build";

	}

	@Override
	public String toString() {
		return builder.toString();
	}

}
