package com.capge.client.saplabs.decorator;

import com.capge.client.saplabs.bean.Vehicle;

public abstract class VehicleDecorator implements Vehicle {
	Vehicle v;

	public VehicleDecorator(Vehicle v) {
		super();
		this.v = v;
	}
}
