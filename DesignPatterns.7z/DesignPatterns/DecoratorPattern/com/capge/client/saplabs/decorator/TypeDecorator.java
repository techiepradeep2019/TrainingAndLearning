package com.capge.client.saplabs.decorator;

import com.capge.client.saplabs.bean.Vehicle;

public class TypeDecorator extends VehicleDecorator {

	private Vehicle v;
	private String vehicleType;
	private final StringBuilder builder = new StringBuilder();

	public TypeDecorator(Vehicle v, String vehicleType) {
		super(v);
		this.v = v;
		this.vehicleType = vehicleType;
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}

	@Override
	public String setUpVehicleType() {
		builder.append(vehicleType);
		return vehicleType;
	}

	@Override
	public String setUpWheel() {
		String wheel = v.setUpWheel();
		builder.append(wheel);
		return wheel;
	}

	@Override
	public String setUpShape() {
		String shape = v.setUpShape();
		builder.append(shape);
		return " and " + shape + " in Shape" + " is build";
	}

	@Override
	public String toString() {
		return builder.toString();
	}
}
