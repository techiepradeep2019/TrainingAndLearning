package com.capge.client.saplabs.decorator;

import com.capge.client.saplabs.bean.Vehicle;

public class ShapeDecorator extends VehicleDecorator {

	private Vehicle v;
	private String shape;
	private final StringBuilder builder = new StringBuilder();

	public ShapeDecorator(Vehicle v, String shape) {
		super(v);
		this.v = v;
		this.shape = shape;
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}

	@Override
	public String setUpVehicleType() {
		String vehicleType = v.setUpVehicleType();
		builder.append(vehicleType);
		return vehicleType;
	}

	@Override
	public String setUpWheel() {
		String wheel = v.setUpWheel();
		builder.append(wheel);
		return wheel;
	}

	@Override
	public String setUpShape() {
		builder.append(" and ").append(shape).append(" in Shape").append(" is build");
		return " and " + shape + " in Shape" + " is build";
	}

	@Override
	public String toString() {
		return builder.toString();
	}
}
