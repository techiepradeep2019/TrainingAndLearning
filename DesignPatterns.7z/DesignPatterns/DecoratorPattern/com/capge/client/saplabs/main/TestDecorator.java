package com.capge.client.saplabs.main;

import com.capge.client.saplabs.bean.Bus;
import com.capge.client.saplabs.bean.Vehicle;
import com.capge.client.saplabs.decorator.ShapeDecorator;
import com.capge.client.saplabs.decorator.TypeDecorator;
import com.capge.client.saplabs.decorator.WheelDecorator;

public class TestDecorator {
	public static void main(String[] args) {

//		Vehicle v = new Car();
//		System.out.println(v);
//
//		v = new Bus();
//		System.out.println(v);
//
//		v = new TwoWheeler();
//		System.out.println(v);

		System.out.println("Decorator ...Examples....");

		Vehicle v = new TypeDecorator(new ShapeDecorator(new WheelDecorator(new Bus(), 6), "Rectangle"), "Big Truck");
//		Vehicle v = new WheelDecorator(new Car(), 3);

		System.out.println(v);
	}
}
