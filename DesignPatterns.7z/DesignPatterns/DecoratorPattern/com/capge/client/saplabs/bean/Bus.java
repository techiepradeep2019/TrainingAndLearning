package com.capge.client.saplabs.bean;

public class Bus implements Vehicle {
	private final StringBuilder builder = new StringBuilder();

	public Bus() {
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}
	
	@Override
	public String setUpVehicleType() {
		builder.append("Bus ");
		return "Bus";

	}

	@Override
	public String setUpWheel() {
		builder.append(" with 4-Wheeler");
		return "4-Wheeler";

	}

	@Override
	public String setUpShape() {
		builder.append(" and Rectangle in Shape").append(" is build");
		return "Rectangle in Shape";

	}

	@Override
	public String toString() {
		return builder.toString();
	}

}
