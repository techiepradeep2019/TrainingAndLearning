package com.capge.client.saplabs.bean;

public class TwoWheeler implements Vehicle {

	private final StringBuilder builder = new StringBuilder();

	public TwoWheeler() {
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}

	public StringBuilder getBuilder() {
		return builder;
	}

	@Override
	public String setUpVehicleType() {
		builder.append("Scooter");
		return "Scooter";

	}

	@Override
	public String setUpWheel() {
		builder.append("  With ").append("2-Wheeler");
		return "2-Wheeler";

	}

	@Override
	public String setUpShape() {
		builder.append(" And Long in Shape").append(" is build");
		return "Long in Shape";

	}

	@Override
	public String toString() {
		return builder.toString();
	}
}
