package com.capge.client.saplabs.bean;

public class Car implements Vehicle {
	private final StringBuilder builder = new StringBuilder();

	public Car() {
		setUpVehicleType();
		setUpWheel();
		setUpShape();
	}

	@Override
	public String setUpVehicleType() {
		builder.append("Car ");
		return "Car";

	}

	@Override
	public String setUpWheel() {
		builder.append(" with 4-Wheeler ");
		return "4-Wheeler";

	}

	@Override
	public String setUpShape() {
		builder.append(" And Square in Shape").append(" is build");
		return "Square in Shape";

	}

	@Override
	public String toString() {
		return builder.toString();
	}
}
