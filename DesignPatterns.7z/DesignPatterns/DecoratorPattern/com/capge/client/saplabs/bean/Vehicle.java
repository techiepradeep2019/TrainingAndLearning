package com.capge.client.saplabs.bean;

public interface Vehicle {

	String setUpVehicleType();

	String setUpWheel();

	String setUpShape();

}
